"""Falcon benchmarks"""

from falcon.bench.bench import main  # NOQA
